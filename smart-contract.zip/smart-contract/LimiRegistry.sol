// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title Limi Hardware Registry
 * @dev Stores verification hashes for Limi modules with access control
 * @author Iffat Iqbal for Limi AI
 */

contract LimiRegistry {
    // ---------- Type Declarations ----------
    struct ModuleVerification {
        string moduleId;
        uint256 timestamp;
        string condition;
        address inspector;
        bytes32 verificationHash;
        bool exists;
    }
    
    // ---------- State Variables ----------
    address public owner;
    address public authorizedInspector;
    uint256 public verificationCount;
    
    // Module ID => Verification record
    mapping(string => ModuleVerification) public modules;
    
    // Module ID => array of historical verification timestamps
    mapping(string => uint256[]) private moduleHistory;
    
    // ---------- Events ----------
    event ModuleVerified(
        string indexed moduleId,
        uint256 timestamp,
        string condition,
        address indexed inspector,
        bytes32 verificationHash
    );
    
    event InspectorUpdated(
        address indexed oldInspector,
        address indexed newInspector,
        address indexed updatedBy
    );
    
    event OwnershipTransferred(
        address indexed previousOwner,
        address indexed newOwner
    );
    
    // ---------- Modifiers ----------
    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner can call this function");
        _;
    }
    
    modifier onlyInspector() {
        require(
            msg.sender == authorizedInspector || msg.sender == owner,
            "Only authorized inspector or owner can call this function"
        );
        _;
    }
    
    modifier moduleExists(string memory _moduleId) {
        require(modules[_moduleId].exists, "Module does not exist in registry");
        _;
    }
    
    // ---------- Constructor ----------
    constructor() {
        owner = msg.sender;
        authorizedInspector = msg.sender;
        verificationCount = 0;
        
        emit InspectorUpdated(address(0), msg.sender, msg.sender);
    }
    
    // ---------- Owner Functions ----------
    
    /**
     * @dev Transfer ownership to new address
     * @param _newOwner Address of new owner
     */
    function transferOwnership(address _newOwner) external onlyOwner {
        require(_newOwner != address(0), "New owner cannot be zero address");
        require(_newOwner != owner, "New owner must be different");
        
        address oldOwner = owner;
        owner = _newOwner;
        
        emit OwnershipTransferred(oldOwner, _newOwner);
    }
    
    /**
     * @dev Update authorized inspector address
     * @param _newInspector Address of new inspector
     */
    function updateInspector(address _newInspector) external onlyOwner {
        require(_newInspector != address(0), "Inspector cannot be zero address");
        require(_newInspector != authorizedInspector, "Inspector must be different");
        
        address oldInspector = authorizedInspector;
        authorizedInspector = _newInspector;
        
        emit InspectorUpdated(oldInspector, _newInspector, msg.sender);
    }
    
    // ---------- Inspector Functions ----------
    
    /**
     * @dev Verify a module and store its data on blockchain
     * @param _moduleId Unique module identifier
     * @param _condition Installation condition (Optimal/Maintenance/Critical)
     */
    function verifyModule(
        string memory _moduleId,
        string memory _condition
    ) external onlyInspector {
        require(bytes(_moduleId).length > 0, "Module ID cannot be empty");
        require(bytes(_condition).length > 0, "Condition cannot be empty");
        
        // Generate verification hash
        bytes32 hash = keccak256(
            abi.encodePacked(
                _moduleId,
                block.timestamp,
                _condition,
                msg.sender,
                block.number
            )
        );
        
        // Store module data
        modules[_moduleId] = ModuleVerification({
            moduleId: _moduleId,
            timestamp: block.timestamp,
            condition: _condition,
            inspector: msg.sender,
            verificationHash: hash,
            exists: true
        });
        
        // Add to history
        moduleHistory[_moduleId].push(block.timestamp);
        verificationCount++;
        
        emit ModuleVerified(
            _moduleId,
            block.timestamp,
            _condition,
            msg.sender,
            hash
        );
    }
    
    /**
     * @dev Batch verify multiple modules (gas efficient)
     * @param _moduleIds Array of module IDs
     * @param _conditions Array of conditions
     */
    function batchVerifyModules(
        string[] memory _moduleIds,
        string[] memory _conditions
    ) external onlyInspector {
        require(
            _moduleIds.length == _conditions.length,
            "Arrays length mismatch"
        );
        require(_moduleIds.length <= 10, "Cannot batch verify more than 10 modules");
        
        for (uint256 i = 0; i < _moduleIds.length; i++) {
            require(bytes(_moduleIds[i]).length > 0, "Module ID cannot be empty");
            require(bytes(_conditions[i]).length > 0, "Condition cannot be empty");
            
            bytes32 hash = keccak256(
                abi.encodePacked(
                    _moduleIds[i],
                    block.timestamp,
                    _conditions[i],
                    msg.sender,
                    block.number
                )
            );
            
            modules[_moduleIds[i]] = ModuleVerification({
                moduleId: _moduleIds[i],
                timestamp: block.timestamp,
                condition: _conditions[i],
                inspector: msg.sender,
                verificationHash: hash,
                exists: true
            });
            
            moduleHistory[_moduleIds[i]].push(block.timestamp);
            verificationCount++;
            
            emit ModuleVerified(
                _moduleIds[i],
                block.timestamp,
                _conditions[i],
                msg.sender,
                hash
            );
        }
    }
    
    // ---------- View Functions ----------
    
    /**
     * @dev Get module verification details
     * @param _moduleId Module ID to query
     * @return Module details
     */
    function getModule(
        string memory _moduleId
    ) external view moduleExists(_moduleId) returns (
        string memory moduleId,
        uint256 timestamp,
        string memory condition,
        address inspector,
        bytes32 verificationHash
    ) {
        ModuleVerification memory m = modules[_moduleId];
        return (
            m.moduleId,
            m.timestamp,
            m.condition,
            m.inspector,
            m.verificationHash
        );
    }
    
    /**
     * @dev Get verification hash for a module
     * @param _moduleId Module ID
     * @return Verification hash
     */
    function getVerificationHash(
        string memory _moduleId
    ) external view moduleExists(_moduleId) returns (bytes32) {
        return modules[_moduleId].verificationHash;
    }
    
    /**
     * @dev Get verification history timestamps for a module
     * @param _moduleId Module ID
     * @return Array of timestamps
     */
    function getModuleHistory(
        string memory _moduleId
    ) external view moduleExists(_moduleId) returns (uint256[] memory) {
        return moduleHistory[_moduleId];
    }
    
    /**
     * @dev Check if module exists
     * @param _moduleId Module ID
     * @return True if exists
     */
    function moduleExists(string memory _moduleId) external view returns (bool) {
        return modules[_moduleId].exists;
    }
    
    /**
     * @dev Verify if a hash matches a module
     * @param _moduleId Module ID
     * @param _hash Hash to verify
     * @return True if hash matches
     */
    function verifyHash(
        string memory _moduleId,
        bytes32 _hash
    ) external view moduleExists(_moduleId) returns (bool) {
        return modules[_moduleId].verificationHash == _hash;
    }
    
    /**
     * @dev Get contract statistics
     * @return Total verifications, owner, inspector
     */
    function getStats() external view returns (
        uint256 totalVerifications,
        address contractOwner,
        address inspector
    ) {
        return (verificationCount, owner, authorizedInspector);
    }
}