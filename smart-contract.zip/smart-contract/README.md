# Limi Hardware Registry Smart Contract

## Contract Address (Sepolia)
`0x...` (Add after deployment)

## Deployment Instructions

### Using Remix IDE (Easiest)

1. Go to https://remix.ethereum.org
2. Create new file `LimiRegistry.sol`
3. Copy the contract code
4. Compile:
   - Select Solidity version 0.8.19
   - Click "Compile"
5. Deploy:
   - Switch to "Deploy & Run Transactions"
   - Environment: "Injected Provider - MetaMask"
   - Select "LimiRegistry" contract
   - Click "Deploy"
   - Confirm in MetaMask

### Using Hardhat (Professional)

```bash
# Install Hardhat
npm init -y
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox

# Create Hardhat project
npx hardhat init

# Add contract to contracts/
# Create deployment script