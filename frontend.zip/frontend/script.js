/**
 * Limi AI Fleet Dashboard
 * Full-stack implementation with Web3 integration
 * @author Iffat Iqbal for Limi AI
 */

// ===== CONFIGURATION =====
const CONFIG = {
    CONTRACT_ADDRESS: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e", // Replace after deployment
    NETWORK: "sepolia",
    RPC_URL: "https://sepolia.infura.io/v3/YOUR_PROJECT_ID", // Replace with your Infura ID
    IPFS_GATEWAY: "https://ipfs.io/ipfs/"
};

// Contract ABI
const CONTRACT_ABI = [
    {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "anonymous": false,
        "inputs": [
            {"indexed": true, "internalType": "address", "name": "oldInspector", "type": "address"},
            {"indexed": true, "internalType": "address", "name": "newInspector", "type": "address"},
            {"indexed": true, "internalType": "address", "name": "updatedBy", "type": "address"}
        ],
        "name": "InspectorUpdated",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {"indexed": true, "internalType": "string", "name": "moduleId", "type": "string"},
            {"indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256"},
            {"indexed": false, "internalType": "string", "name": "condition", "type": "string"},
            {"indexed": true, "internalType": "address", "name": "inspector", "type": "address"},
            {"indexed": false, "internalType": "bytes32", "name": "verificationHash", "type": "bytes32"}
        ],
        "name": "ModuleVerified",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {"indexed": true, "internalType": "address", "name": "previousOwner", "type": "address"},
            {"indexed": true, "internalType": "address", "name": "newOwner", "type": "address"}
        ],
        "name": "OwnershipTransferred",
        "type": "event"
    },
    {
        "inputs": [
            {"internalType": "string[]", "name": "_moduleIds", "type": "string[]"},
            {"internalType": "string[]", "name": "_conditions", "type": "string[]"}
        ],
        "name": "batchVerifyModules",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_moduleId", "type": "string"}
        ],
        "name": "getModule",
        "outputs": [
            {"internalType": "string", "name": "moduleId", "type": "string"},
            {"internalType": "uint256", "name": "timestamp", "type": "uint256"},
            {"internalType": "string", "name": "condition", "type": "string"},
            {"internalType": "address", "name": "inspector", "type": "address"},
            {"internalType": "bytes32", "name": "verificationHash", "type": "bytes32"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_moduleId", "type": "string"}
        ],
        "name": "getModuleHistory",
        "outputs": [
            {"internalType": "uint256[]", "name": "", "type": "uint256[]"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getStats",
        "outputs": [
            {"internalType": "uint256", "name": "totalVerifications", "type": "uint256"},
            {"internalType": "address", "name": "contractOwner", "type": "address"},
            {"internalType": "address", "name": "inspector", "type": "address"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_moduleId", "type": "string"}
        ],
        "name": "getVerificationHash",
        "outputs": [
            {"internalType": "bytes32", "name": "", "type": "bytes32"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_moduleId", "type": "string"}
        ],
        "name": "moduleExists",
        "outputs": [
            {"internalType": "bool", "name": "", "type": "bool"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "", "type": "string"}
        ],
        "name": "modules",
        "outputs": [
            {"internalType": "string", "name": "moduleId", "type": "string"},
            {"internalType": "uint256", "name": "timestamp", "type": "uint256"},
            {"internalType": "string", "name": "condition", "type": "string"},
            {"internalType": "address", "name": "inspector", "type": "address"},
            {"internalType": "bytes32", "name": "verificationHash", "type": "bytes32"},
            {"internalType": "bool", "name": "exists", "type": "bool"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "address", "name": "_newInspector", "type": "address"}
        ],
        "name": "updateInspector",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "address", "name": "_newOwner", "type": "address"}
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_moduleId", "type": "string"},
            {"internalType": "bytes32", "name": "_hash", "type": "bytes32"}
        ],
        "name": "verifyHash",
        "outputs": [
            {"internalType": "bool", "name": "", "type": "bool"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_moduleId", "type": "string"},
            {"internalType": "string", "name": "_condition", "type": "string"}
        ],
        "name": "verifyModule",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "authorizedInspector",
        "outputs": [
            {"internalType": "address", "name": "", "type": "address"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [
            {"internalType": "address", "name": "", "type": "address"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "verificationCount",
        "outputs": [
            {"internalType": "uint256", "name": "", "type": "uint256"}
        ],
        "stateMutability": "view",
        "type": "function"
    }
];

// ===== MAIN DASHBOARD CLASS =====
class LimiDashboard {
    constructor() {
        // Core properties
        this.web3 = null;
        this.contract = null;
        this.account = null;
        this.chainId = null;
        this.isInspector = false;
        
        // Module data
        this.modules = [
            {
                id: "L-701",
                signal: "98%",
                location: "Zone A",
                condition: "Optimal",
                verified: true,
                timestamp: new Date().toISOString(),
                txHash: "0x742d35cc6634c0532925a3b844bc454e4438f44e"
            },
            {
                id: "L-702",
                signal: "75%",
                location: "Zone B",
                condition: "Needs Maintenance",
                verified: true,
                timestamp: new Date().toISOString(),
                txHash: "0x842d35cc6634c0532925a3b844bc454e4438f44e"
            },
            {
                id: "L-703",
                signal: "45%",
                location: "Zone C",
                condition: "Critical",
                verified: true,
                timestamp: new Date().toISOString(),
                txHash: "0x942d35cc6634c0532925a3b844bc454e4438f44e"
            }
        ];
        
        // Initialize
        this.init();
    }
    
    async init() {
        this.cacheDOM();
        this.bindEvents();
        this.checkWalletConnection();
        this.renderModules();
        this.updateStats();
        this.setupResponsive();
    }
    
    cacheDOM() {
        // DOM elements
        this.elements = {
            menuToggle: document.getElementById('menuToggle'),
            sidebar: document.querySelector('.sidebar'),
            connectWalletBtn: document.getElementById('connectWalletBtn'),
            walletInfo: document.getElementById('walletInfo'),
            walletAddress: document.getElementById('walletAddress'),
            walletBalance: document.getElementById('walletBalance'),
            uploadArea: document.getElementById('uploadArea'),
            fileInput: document.getElementById('fileInput'),
            extractionProgress: document.getElementById('extractionProgress'),
            progressFill: document.getElementById('progressFill'),
            progressStatus: document.getElementById('progressStatus'),
            extractedData: document.getElementById('extractedData'),
            extractedModuleId: document.getElementById('extractedModuleId'),
            extractedSignal: document.getElementById('extractedSignal'),
            extractedLocation: document.getElementById('extractedLocation'),
            extractedCondition: document.getElementById('extractedCondition'),
            verifyOnChainBtn: document.getElementById('verifyOnChainBtn'),
            addToDashboardBtn: document.getElementById('addToDashboardBtn'),
            modulesGrid: document.getElementById('modulesGrid'),
            totalModules: document.getElementById('totalModules'),
            optimalCount: document.getElementById('optimalCount'),
            maintenanceCount: document.getElementById('maintenanceCount'),
            criticalCount: document.getElementById('criticalCount'),
            gridView: document.getElementById('gridView'),
            listView: document.getElementById('listView'),
            txModal: document.getElementById('txModal'),
            txStatus: document.getElementById('txStatus'),
            txDetails: document.getElementById('txDetails'),
            txHash: document.getElementById('txHash'),
            txBlock: document.getElementById('txBlock'),
            txGas: document.getElementById('txGas'),
            closeModalBtn: document.getElementById('closeModalBtn')
        };
    }
    
    bindEvents() {
        // Menu toggle
        this.elements.menuToggle.addEventListener('click', () => {
            this.elements.sidebar.classList.toggle('active');
        });
        
        // Wallet connection
        this.elements.connectWalletBtn.addEventListener('click', () => this.connectWallet());
        
        // File upload
        this.elements.uploadArea.addEventListener('click', () => {
            this.elements.fileInput.click();
        });
        
        this.elements.uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.elements.uploadArea.style.borderColor = '#00fff5';
        });
        
        this.elements.uploadArea.addEventListener('dragleave', () => {
            this.elements.uploadArea.style.borderColor = '';
        });
        
        this.elements.uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            this.elements.uploadArea.style.borderColor = '';
            const file = e.dataTransfer.files[0];
            if (file) this.handleFileUpload(file);
        });
        
        this.elements.fileInput.addEventListener('change', (e) => {
            if (e.target.files[0]) this.handleFileUpload(e.target.files[0]);
        });
        
        // Action buttons
        this.elements.verifyOnChainBtn.addEventListener('click', () => this.verifyOnBlockchain());
        this.elements.addToDashboardBtn.addEventListener('click', () => this.addToDashboard());
        
        // View toggle
        this.elements.gridView.addEventListener('click', () => {
            this.elements.gridView.classList.add('active');
            this.elements.listView.classList.remove('active');
            this.elements.modulesGrid.className = 'modules-grid';
        });
        
        this.elements.listView.addEventListener('click', () => {
            this.elements.listView.classList.add('active');
            this.elements.gridView.classList.remove('active');
            this.elements.modulesGrid.className = 'modules-grid list-view';
        });
        
        // Modal close
        this.elements.closeModalBtn.addEventListener('click', () => {
            this.elements.txModal.style.display = 'none';
        });
        
        window.addEventListener('click', (e) => {
            if (e.target === this.elements.txModal) {
                this.elements.txModal.style.display = 'none';
            }
        });
        
        // Click outside sidebar to close on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 992) {
                if (!this.elements.sidebar.contains(e.target) && 
                    !this.elements.menuToggle.contains(e.target)) {
                    this.elements.sidebar.classList.remove('active');
                }
            }
        });
    }
    
    setupResponsive() {
        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 992) {
                this.elements.sidebar.classList.remove('active');
            }
        });
    }
    
    // ===== WEB3 FUNCTIONS =====
    async checkWalletConnection() {
        if (typeof window.ethereum !== 'undefined') {
            try {
                const accounts = await window.ethereum.request({ method: 'eth_accounts' });
                if (accounts.length > 0) {
                    this.account = accounts[0];
                    this.web3 = new Web3(window.ethereum);
                    await this.initContract();
                    this.updateWalletUI();
                }
            } catch (error) {
                console.error('Error checking wallet connection:', error);
            }
        }
    }
    
    async connectWallet() {
        if (typeof window.ethereum === 'undefined') {
            this.showNotification('Please install MetaMask!', 'error');
            return;
        }
        
        try {
            // Request accounts
            const accounts = await window.ethereum.request({ 
                method: 'eth_requestAccounts' 
            });
            
            this.account = accounts[0];
            this.web3 = new Web3(window.ethereum);
            
            // Get chain ID
            this.chainId = await window.ethereum.request({ 
                method: 'eth_chainId' 
            });
            
            // Check if on Sepolia
            if (this.chainId !== '0xaa36a7') { // Sepolia chain ID
                this.showNotification('Please switch to Sepolia network', 'warning');
                await this.switchToSepolia();
            }
            
            // Initialize contract
            await this.initContract();
            
            // Update UI
            this.updateWalletUI();
            this.showNotification('Wallet connected successfully!', 'success');
            
            // Listen for account changes
            window.ethereum.on('accountsChanged', (accounts) => {
                if (accounts.length === 0) {
                    this.disconnectWallet();
                } else {
                    this.account = accounts[0];
                    this.updateWalletUI();
                }
            });
            
            // Listen for chain changes
            window.ethereum.on('chainChanged', (chainId) => {
                this.chainId = chainId;
                if (chainId !== '0xaa36a7') {
                    this.showNotification('Please switch to Sepolia network', 'warning');
                }
            });
            
        } catch (error) {
            console.error('Error connecting wallet:', error);
            this.showNotification('Failed to connect wallet', 'error');
        }
    }
    
    async switchToSepolia() {
        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: '0xaa36a7' }] // Sepolia chain ID
            });
        } catch (error) {
            // If Sepolia not added, add it
            if (error.code === 4902) {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: '0xaa36a7',
                        chainName: 'Sepolia',
                        nativeCurrency: {
                            name: 'Sepolia ETH',
                            symbol: 'ETH',
                            decimals: 18
                        },
                        rpcUrls: ['https://sepolia.infura.io/v3/'],
                        blockExplorerUrls: ['https://sepolia.etherscan.io']
                    }]
                });
            }
        }
    }
    
    async initContract() {
        if (!this.web3 || !CONFIG.CONTRACT_ADDRESS) return;
        
        try {
            this.contract = new this.web3.eth.Contract(
                CONTRACT_ABI,
                CONFIG.CONTRACT_ADDRESS
            );
            
            // Check if current account is inspector
            const inspector = await this.contract.methods.authorizedInspector().call();
            this.isInspector = inspector.toLowerCase() === this.account.toLowerCase();
            
            // Load contract stats
            const stats = await this.contract.methods.getStats().call();
            console.log('Contract stats:', stats);
            
        } catch (error) {
            console.error('Error initializing contract:', error);
        }
    }
    
    async getBalance() {
        if (!this.web3 || !this.account) return '0';
        
        try {
            const balance = await this.web3.eth.getBalance(this.account);
            return this.web3.utils.fromWei(balance, 'ether');
        } catch (error) {
            console.error('Error getting balance:', error);
            return '0';
        }
    }
    
    updateWalletUI() {
        if (this.account) {
            this.elements.connectWalletBtn.style.display = 'none';
            this.elements.walletInfo.style.display = 'flex';
            
            // Format address
            const shortAddress = `${this.account.substring(0, 6)}...${this.account.substring(38)}`;
            this.elements.walletAddress.textContent = shortAddress;
            
            // Get and display balance
            this.getBalance().then(balance => {
                this.elements.walletBalance.textContent = `${parseFloat(balance).toFixed(4)} ETH`;
            });
        } else {
            this.elements.connectWalletBtn.style.display = 'flex';
            this.elements.walletInfo.style.display = 'none';
        }
    }
    
    disconnectWallet() {
        this.account = null;
        this.web3 = null;
        this.contract = null;
        this.updateWalletUI();
        this.showNotification('Wallet disconnected', 'info');
    }
    
    // ===== AI SIMULATION =====
    async handleFileUpload(file) {
        // Validate file
        const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        if (!validTypes.includes(file.type)) {
            this.showNotification('Please upload a PDF or image file', 'error');
            return;
        }
        
        if (file.size > 10 * 1024 * 1024) {
            this.showNotification('File size must be less than 10MB', 'error');
            return;
        }
        
        // Show progress
        this.elements.extractionProgress.style.display = 'block';
        this.elements.extractedData.style.display = 'none';
        
        // Simulate AI processing
        await this.simulateAIProcessing(file);
    }
    
    async simulateAIProcessing(file) {
        const steps = [
            'Preprocessing image...',
            'Running OCR...',
            'Extracting text...',
            'Analyzing with NLP...',
            'Classifying condition...'
        ];
        
        for (let i = 0; i < steps.length; i++) {
            this.elements.progressStatus.textContent = steps[i];
            this.elements.progressFill.style.width = `${(i + 1) * 20}%`;
            await this.sleep(800);
        }
        
        // Generate random but realistic data
        const modules = ['L-701', 'L-702', 'L-703', 'L-704', 'L-705'];
        const conditions = ['Optimal', 'Needs Maintenance', 'Critical'];
        const zones = ['A', 'B', 'C', 'D'];
        
        const randomModule = modules[Math.floor(Math.random() * modules.length)];
        const randomSignal = Math.floor(Math.random() * 40) + 60; // 60-100%
        const randomZone = zones[Math.floor(Math.random() * zones.length)];
        
        // Determine condition based on signal
        let condition;
        if (randomSignal >= 90) condition = 'Optimal';
        else if (randomSignal >= 70) condition = 'Needs Maintenance';
        else condition = 'Critical';
        
        // Update UI
        this.elements.extractedModuleId.textContent = randomModule;
        this.elements.extractedSignal.textContent = `${randomSignal}%`;
        this.elements.extractedLocation.textContent = `Zone ${randomZone}`;
        this.elements.extractedCondition.textContent = condition;
        this.elements.extractedCondition.className = `status-badge ${condition.toLowerCase().replace(' ', '-')}`;
        
        // Store for later use
        this.currentExtractedData = {
            moduleId: randomModule,
            signal: `${randomSignal}%`,
            location: `Zone ${randomZone}`,
            condition: condition
        };
        
        // Hide progress, show data
        this.elements.extractionProgress.style.display = 'none';
        this.elements.extractedData.style.display = 'block';
        
        this.showNotification('AI analysis complete!', 'success');
    }
    
    // ===== BLOCKCHAIN FUNCTIONS =====
    async verifyOnBlockchain() {
        if (!this.account) {
            this.showNotification('Please connect your wallet first', 'warning');
            return;
        }
        
        if (!this.currentExtractedData) {
            this.showNotification('No data to verify', 'warning');
            return;
        }
        
        if (!this.isInspector) {
            this.showNotification('Your wallet is not an authorized inspector', 'error');
            return;
        }
        
        // Show modal
        this.elements.txModal.style.display = 'flex';
        this.elements.txStatus.innerHTML = '<i class="fas fa-spinner fa-spin"></i><p>Waiting for MetaMask confirmation...</p>';
        this.elements.txDetails.style.display = 'none';
        
        try {
            // Prepare transaction
            const moduleId = this.currentExtractedData.moduleId;
            const condition = this.currentExtractedData.condition;
            
            // Estimate gas
            const gasEstimate = await this.contract.methods
                .verifyModule(moduleId, condition)
                .estimateGas({ from: this.account });
            
            // Send transaction
            const result = await this.contract.methods
                .verifyModule(moduleId, condition)
                .send({ 
                    from: this.account,
                    gas: Math.floor(gasEstimate * 1.2) // Add 20% buffer
                });
            
            // Update modal with success
            this.elements.txStatus.innerHTML = '<i class="fas fa-check-circle" style="color: #00ff88;"></i><p>Transaction confirmed!</p>';
            this.elements.txDetails.style.display = 'block';
            this.elements.txHash.textContent = result.transactionHash;
            this.elements.txBlock.textContent = result.blockNumber;
            this.elements.txGas.textContent = result.gasUsed;
            
            // Add to modules
            this.modules.push({
                id: moduleId,
                signal: this.currentExtractedData.signal,
                location: this.currentExtractedData.location,
                condition: condition,
                verified: true,
                timestamp: new Date().toISOString(),
                txHash: result.transactionHash
            });
            
            this.renderModules();
            this.updateStats();
            
            this.showNotification('Module verified on blockchain!', 'success');
            
        } catch (error) {
            console.error('Blockchain verification error:', error);
            
            // Update modal with error
            this.elements.txStatus.innerHTML = '<i class="fas fa-times-circle" style="color: #ff4444;"></i><p>Transaction failed</p>';
            this.elements.txDetails.style.display = 'block';
            this.elements.txDetails.innerHTML = `<p>Error: ${error.message.substring(0, 100)}...</p>`;
            
            this.showNotification('Blockchain verification failed', 'error');
        }
    }
    
    // ===== DASHBOARD FUNCTIONS =====
    renderModules() {
        let html = '';
        
        this.modules.forEach(module => {
            const statusClass = module.condition.toLowerCase().replace(' ', '-');
            const verifiedIcon = module.verified ? '🔗' : '⏳';
            
            html += `
                <div class="module-card" data-id="${module.id}">
                    <div class="module-header">
                        <span class="module-id">${module.id}</span>
                        <span class="module-status status-${statusClass}">${module.condition}</span>
                    </div>
                    <div class="module-body">
                        <div class="module-info">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${module.location}</span>
                        </div>
                        <div class="module-info">
                            <i class="fas fa-signal"></i>
                            <span>Signal: ${module.signal}</span>
                        </div>
                        <div class="module-info">
                            <i class="fas fa-link"></i>
                            <span>${verifiedIcon} ${module.verified ? 'Verified' : 'Pending'}</span>
                        </div>
                        <div class="module-info">
                            <i class="fas fa-clock"></i>
                            <span>${new Date(module.timestamp).toLocaleDateString()}</span>
                        </div>
                    </div>
                    <div class="module-footer">
                        <button class="btn-verify" onclick="dashboard.verifyModule('${module.id}')">
                            <i class="fas fa-link"></i> Verify
                        </button>
                        <button class="btn-view" onclick="dashboard.viewModule('${module.id}')">
                            <i class="fas fa-search"></i> View
                        </button>
                    </div>
                </div>
            `;
        });
        
        this.elements.modulesGrid.innerHTML = html;
    }
    
    updateStats() {
        const stats = this.modules.reduce((acc, module) => {
            const condition = module.condition.toLowerCase();
            if (condition.includes('optimal')) acc.optimal++;
            else if (condition.includes('maintenance')) acc.maintenance++;
            else if (condition.includes('critical')) acc.critical++;
            return acc;
        }, { optimal: 0, maintenance: 0, critical: 0 });
        
        this.elements.totalModules.textContent = this.modules.length;
        this.elements.optimalCount.textContent = stats.optimal;
        this.elements.maintenanceCount.textContent = stats.maintenance;
        this.elements.criticalCount.textContent = stats.critical;
    }
    
    addToDashboard() {
        if (!this.currentExtractedData) return;
        
        this.modules.push({
            ...this.currentExtractedData,
            verified: false,
            timestamp: new Date().toISOString()
        });
        
        this.renderModules();
        this.updateStats();
        this.elements.extractedData.style.display = 'none';
        this.elements.fileInput.value = '';
        
        this.showNotification('Module added to dashboard', 'success');
    }
    
    verifyModule(moduleId) {
        const module = this.modules.find(m => m.id === moduleId);
        if (module) {
            this.currentExtractedData = module;
            this.verifyOnBlockchain();
        }
    }
    
    viewModule(moduleId) {
        const module = this.modules.find(m => m.id === moduleId);
        if (module) {
            alert(`Module Details:\nID: ${module.id}\nSignal: ${module.signal}\nLocation: ${module.location}\nCondition: ${module.condition}\nVerified: ${module.verified ? 'Yes' : 'No'}`);
        }
    }
    
    // ===== UTILITY FUNCTIONS =====
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas ${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
        `;
        
        // Style it
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 24px;
            background: ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4444' : type === 'warning' ? '#ffd700' : '#00fff5'};
            color: ${type === 'warning' ? '#000' : '#fff'};
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 1001;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    getNotificationIcon(type) {
        switch(type) {
            case 'success': return 'fa-check-circle';
            case 'error': return 'fa-times-circle';
            case 'warning': return 'fa-exclamation-triangle';
            default: return 'fa-info-circle';
        }
    }
}

// Initialize dashboard
const dashboard = new LimiDashboard();

// Make functions available globally for onclick handlers
window.dashboard = dashboard;