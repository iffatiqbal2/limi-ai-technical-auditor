# Limi Network Topology Design (Huawei eNSP)

## 📋 Overview
This document describes the network topology for connecting 3 Limi Hubs to a central Cloud Server using Huawei eNSP.

## 🖥️ Topology Diagram
